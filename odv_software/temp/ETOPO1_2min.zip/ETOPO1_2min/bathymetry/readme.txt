ETOPO1_2min Series: global extent
(c) R. Schlitzer (November/2010)

bathymetry based on: ETOPO1 1 minute dataset (Amante, C. and
                     B. W. Eakins, ETOPO1 1 Arc-Minute Global Relief
                     Model: Procedures, Data Sources and
                     Analysis. NOAA Technical Memorandum NESDIS
                     NGDC-24, 19 pp, March 2009.).

                     Subsampled at 2 x 2 minute resolution
