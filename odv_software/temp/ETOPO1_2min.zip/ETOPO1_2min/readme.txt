ETOPO1_2min Series: global extent
(c) R. Schlitzer (November/2010)

Download size:       246 MB
Required disk space: 514 MB


World.cdt: >>>>north of 60S

           GSHHS - A Global Self-consistent, Hierarchical, High-resolution
           Shoreline Database.


           >>>>south of  60S

	   GEBCO Digital Atlas CD-ROM CentenaryEdition, 2003 (CD2,
           SCAR/FULL.ASC).

           Combination of 
           '22010' for ice coastline (definite)
           '22011' for rock coastline (definite)
           '22020' for ice coastline (approximate)
           '22021' for rock coastline (approximate)
           '22050' for ice shelf front

	   >>>>Subsampled using the following steps: 

	   (1) reduced resolution to 0.001 degrees
	   (2) deleted short segments of less than 5 points
