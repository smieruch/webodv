ETOPO1_2min Series: global extent
(c) R. Schlitzer (November/2010)

Lakes, rivers, borders: CIA World Data Bank II (note that rivers and
                        borders may be stroked but not filled; lakes
                        may be stroked and filled)

	   Subsampled using the following steps: 

	   (1) reduced resolution to 0.001 degrees
	   (2) deleted short segments of less than 5 points
