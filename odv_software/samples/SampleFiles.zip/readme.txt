This directory contains sample files.


someSAVE.txt      ODV generic spreadsheet import data file.

import4.o4x       ODV4.x Listing import data file.

import3.o3x       ODV3.0 Listing import data file.
import3.var       ODV3.0 Listing import variables file.



1000m.coa         Sample ASCII coastline/bathymetry file.



pssample.tex      Sample LaTeX file showing import of ODV PostScript
                  files into TeX documents.


aou.mac
mpd.mac           Sample macro files for derived variables.



MapOverlays.gif   GIF files of a map with many layers.



WOA94.lst         Sample file list for WOA94 multiple files import.
